export { default } from './InstructorToolbar';
