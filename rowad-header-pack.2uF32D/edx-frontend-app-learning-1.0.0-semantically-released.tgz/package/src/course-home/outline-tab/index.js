export { default } from './OutlineTab';
