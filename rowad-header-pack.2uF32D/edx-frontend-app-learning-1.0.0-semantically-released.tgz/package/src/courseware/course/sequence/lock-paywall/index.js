export { default } from './LockPaywall';
