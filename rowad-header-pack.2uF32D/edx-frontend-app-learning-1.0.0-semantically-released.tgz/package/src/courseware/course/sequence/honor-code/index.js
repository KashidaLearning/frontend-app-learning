export { default } from './HonorCode';
