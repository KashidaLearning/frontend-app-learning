export { default } from './CoursewareContainer';
